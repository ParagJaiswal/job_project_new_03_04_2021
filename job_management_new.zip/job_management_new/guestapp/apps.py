from django.apps import AppConfig


class GuestappConfig(AppConfig):
    name = 'guestapp'
