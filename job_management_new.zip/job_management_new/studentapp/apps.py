from django.apps import AppConfig


class StudentappConfig(AppConfig):
    name = 'studentapp'
