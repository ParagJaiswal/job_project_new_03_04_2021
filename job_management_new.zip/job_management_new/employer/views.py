from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import hrreg,PostJob,AppliedStudent
from webadmin.models import CourseData

def index(request):
	return render(request,'employer/index.html')

def register(request):
	if request.method=='POST':
		record = hrreg(Full_Name=request.POST['name'],Company_Name=request.POST['cname'],
			Email=request.POST['email'],Password=request.POST['password'],Mobile=request.POST['mobile'],Status=0)
		record.save()
		return redirect(login)
	return render(request,'employer/register.html')

def login(request):
	if request.method =='POST':
		check = hrreg.objects.filter(Email=request.POST['txtemail'],Password=request.POST['txtpass']).values_list('Status',flat=True)
		if check.count()>0:
			c = check[0]
			if c=='1':
				request.session['uemail']= request.POST['txtemail']
				return redirect('hrdash')
			else:
				return render(request,'employer/login.html',{"notapprove":'Not approve'})

		else:
			return render(request,'employer/login.html',{'invalid':"Invalid"})

	return render(request,'employer/login.html')

def hrdash(request):
	if request.session.has_key('uemail'):
		uemail = request.session['uemail']
		return render(request,'employer/hrdash.html')
	

def postjob(request):
	tech = CourseData.objects.all()
	if request.method =='POST':
		post_job_data = PostJob(Technology=request.POST['technology'],Job_Description=request.POST['desc'],Experience=request.POST['exp'],
			Company_Name=request.POST['cname'],Company_Email=request.POST['cemail'],Company_Contact=request.POST['cnumber'],
			Post_Date=request.POST['postdt'],Expiry_Date=request.POST['expdt'],Status=0)
		post_job_data.save()

		return render(request,'employer/postjob.html',{'upload':"Job Posted, Wait For Admin Approval "})

	return render(request,'employer/postjob.html',{'tech':tech})


def appliedstudent(request):
	uemail = request.session['uemail']
	cn = hrreg.objects.filter(Email=uemail).values_list('Company_Name',flat=True)
	com_name= cn[0]
	
	students = AppliedStudent.objects.all()
	
	
	return render(request,'employer/appliedstudent.html',{'students':students,'com_name':com_name})

	