from django.apps import AppConfig


class EmployerConfig(AppConfig):
    name = 'employer'
