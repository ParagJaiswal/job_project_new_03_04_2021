from django.db import models

class AdminLogin(models.Model):
	Username = models.CharField(max_length=20)
	Password = models.CharField(max_length=20)

	def __str__(self):
		return "Username is "+ self.Username+" "+"& Password is "+self.Password

class CourseData(models.Model):
	Course_ID = models.CharField(max_length=10)
	Course_Name = models.CharField(max_length=30)

	def __str__(self):
		return self.Course_Name + " "+ self.Course_ID

class StudentRecord(models.Model):
	Full_Name = models.CharField(max_length=30)
	Mobile =models.CharField(max_length=12)
	Email = models.CharField(max_length=30)
	Course = models.CharField(max_length=30)
	Description = models.CharField(max_length=30)
	Branch = models.CharField(max_length=30)
	Passing_Year = models.CharField(max_length=30)
	Secondary_Percentage = models.CharField(max_length=10)
	Higher_Secondary_Percentage = models.CharField(max_length=10)
	Graduation_Stream = models.CharField(max_length=20)
	Graduation_Percentage = models.CharField(max_length=10)
	Post_Graduation_Stream = models.CharField(max_length=20)
	Post_Graduation_Percentage = models.CharField(max_length=10)
	Other_Certification = models.CharField(max_length=50)

	
	def __str__(self):
		return self.Full_Name+ " "+ self.Course 