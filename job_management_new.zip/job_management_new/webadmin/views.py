from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import AdminLogin,CourseData,StudentRecord
from studentapp.models import StudentReg
from employer.models import hrreg,PostJob

def adminlogin(request):
	if request.method == 'POST':
		if request.POST.get('log'):
			access = AdminLogin.objects.filter(Username=request.POST['txtuser'],Password=request.POST['txtpass'])
			if access.count()>0:
				redirect(admindash)
			else:
				return HttpResponse('Invalid')

	return render(request,'webadmin/adminlogin.html')

def admindash(request):
	approvals = StudentReg.objects.all()
	return render(request,'webadmin/adminhome.html',{'approvals':approvals})

def register(request):
	coursedata = CourseData.objects.all()
	if request.method == "POST":
		if request.POST.get('regbtn'):
			strecord = StudentRecord(Full_Name=request.POST['txtname'],Mobile=request.POST['txtmobile'],Email=request.POST['txtemail'],Course=request.POST['course'],
				Description=request.POST['description'],Branch=request.POST['txtbranch'],Passing_Year=request.POST['txtpassingyear'],Secondary_Percentage=request.POST['txtsec'],
				Higher_Secondary_Percentage=request.POST['txthigher-sec'],Graduation_Stream=request.POST['txtgraduation-stream'],Graduation_Percentage=request.POST['txtgraduation-percentage'],
				Post_Graduation_Stream=request.POST['txtpg-stream'],Post_Graduation_Percentage=request.POST['txtpg-percentage'],Other_Certification=request.POST['txtother-qualification'])

			strecord.save()
			return render(request,'webadmin/register.html',{'msg':"Form Submitted",'coursedata':coursedata})
		elif request.POST.get('clearbtn'):
			return render(request,'webadmin/register.html')
		

	return render(request,'webadmin/register.html',{'coursedata':coursedata})


def showrecords(request):
	viewrecords = StudentRecord.objects.all()
	return render(request,'webadmin/showrecords.html',{'viewrecords':viewrecords})


def stuedit(request):	
	selectedstu = StudentRecord.objects.get(pk=request.GET['id'])
	if request.method=='POST':
		if request.POST.get('update'):
			selectedstu.Full_Name=request.POST['txtname']
			selectedstu.Mobile=request.POST['txtmobile']
			selectedstu.Email=request.POST['txtemail']
			selectedstu.Course=request.POST['txtcourse']
			selectedstu.Description=request.POST['txtarea']
			selectedstu.Branch=request.POST['txtbranch']
			selectedstu.Passing_Year=request.POST['txtpassing_year']
			selectedstu.Secondary_Percentage=request.POST['txtsecondarypercentage']
			selectedstu.Higher_Secondary_Percentage=request.POST['txthighsecondarypercentage']
			selectedstu.Graduation_Stream=request.POST['graduationstream']
			selectedstu.Graduation_Percentage=request.POST['graduationpercentage']
			selectedstu.Post_Graduation_Stream=request.POST['post-graduationstream']
			selectedstu.Post_Graduation_Percentage=request.POST['post-graduationpercentage']
			selectedstu.Other_Certification=request.POST['txtother-certification']
			selectedstu.save()
			return redirect(showrecords)
		else:
			return redirect(showrecords)

	return render(request,'webadmin/stuedit.html',{'stuedit':selectedstu})

def studel(request):
	selectedstu = StudentRecord.objects.get(pk=request.GET['id'])
	if request.method== 'POST':
		if request.POST.get('yes'):
			selectedstu.delete()
			return redirect(showrecords)
		else:
			return redirect(showrecords)
	return render(request,'webadmin/studel.html',{'selectedstu':selectedstu})

def coursemaster(request):
	if request.method =='POST':
		if request.POST.get('btn'):
			cd = CourseData(Course_ID=request.POST['courseid'], Course_Name=request.POST['coursename'])
			cd.save()
			return render(request,'webadmin/addcourse.html',{'success':"Course Successfully added"})
		else:
			return render(request,'webadmin/adminhome.html')
	return render(request,'webadmin/addcourse.html')

def viewcourses(request):
	showcourses= CourseData.objects.all()
	return render(request,'webadmin/viewcourses.html',{'showcourses':showcourses})

def courseedit(request):
	cedit = CourseData.objects.get(pk=request.GET['id'])
	if request.method=='POST':
		if request.POST.get('update'):
			cedit.Course_ID = request.POST['courseid']
			cedit.Course_Name = request.POST['coursename']
			cedit.save()
			return render(request,'webadmin/cedit.html',{'cedit':cedit,"changes":"Changes Has Been Done"})
		else:
			return redirect('viewcourses')
	return render(request,'webadmin/cedit.html',{'cedit':cedit})

def deletecourse(request):
	cdelete = CourseData.objects.get(pk=request.GET['id'])
	if request.method =='POST':
		if request.POST.get('yes'):
			cdelete.delete()
			return redirect('viewcourses')
		else:
			return redirect('viewcourses')
	return render(request,'webadmin/cdelete.html',{'cdelete':cdelete})

def logout(request):
	return redirect('adminlogin')

def approve(request):
	
	status = request.GET['s']
	ID = request.GET['id']
	select = StudentReg.objects.get(pk=ID)
	select.Status=status
	select.save()
	
	return redirect('admindash')

def hrrequest(request):
	records = hrreg.objects.all()
	return render(request,'webadmin/hrrequest.html',{'records':records})

def hrapprove(request):
	st = request.GET['s']
	hr_by_id = request.GET['id']

	hr_record = hrreg.objects.get(pk=hr_by_id)
	hr_record.Status = st
	hr_record.save()

	return redirect('hrrequest')

def postjobapproval(request):
	post_job_data = PostJob.objects.all()
	return render(request,'webadmin/postjobapproval.html',{'post_job_data':post_job_data})

def jobstatus(request):
	st = request.GET['s']
	job_id =request.GET['id']
	find_posted_job = PostJob.objects.get(pk=job_id)
	find_posted_job.Status=st
	find_posted_job.save()
	return redirect('postjobapproval')
